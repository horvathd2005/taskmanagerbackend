const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  title: String,
  description: String,
  status: { type: String, default: 'Pending' },
  priority: { type: String, default: 'Normal' },
  date: { type: Date, default: Date.now },
  dueDate: Date,
  attachments: [{ type: String }],
});

module.exports = mongoose.model('Task', taskSchema);
