
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const User = require('./models/user');
const Task = require('./models/task');

const app = express();
const port = process.env.PORT || 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost/taskmanager', { useNewUrlParser: true, useUnifiedTopology: true });

// Configure middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: '', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

// Passport configuration
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Routes
app.get('/', (req, res) => {
  res.send('Hello, this is your Task Manager app!');
});

// Authentication routes
app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.register(new User({ username }), password);
    res.json(user);
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).send('Internal server error');
  }
});

app.post('/login', passport.authenticate('local'), (req, res) => {
  res.json(req.user);
});

app.get('/logout', (req, res) => {
  req.logout();
  res.send('Logged out successfully');
});

// Task routes
app.get('/tasks', async (req, res) => {
  try {
    const tasks = await Task.find();
    res.json(tasks);
  } catch (error) {
    console.error('Error querying tasks:', error);
    res.status(500).send('Internal server error');
  }
});

app.post('/tasks', async (req, res) => {
  const { title, description, status, priority, date, dueDate, attachments } = req.body;

  try {
    const newTask = new Task({ title, description, status, priority, date, dueDate, attachments });
    await newTask.save();
    res.json(newTask);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).send('Internal server error');
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});
